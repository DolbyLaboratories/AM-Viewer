import scapy

while not (self.mainThread.is_reset() or self.mainThread.stopped()):
	try:
		packets = scapy.sniff(iface=en12, filter="ip dst 10.106.1.1.156 and udp dst port 5004", 42, timeout=1) #, store=0)
	except:
		packets = []
