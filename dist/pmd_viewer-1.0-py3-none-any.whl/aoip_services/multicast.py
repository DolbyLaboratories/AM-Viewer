import socket
import struct
import sys
import netifaces
import platform

class MulticastGroup:

    interface = None
    sock = None
    address = None
    port = None
    localIp = None

    def join(self,interface, address, port):
        """
        Creates a socket, sets the necessary options on it, then binds it. The socket is then returned for use.
        """

        self.interface = interface
        self.localIp = netifaces.ifaddresses(interface)[netifaces.AF_INET][0]['addr']
        self.port = port
        self.address = address
        # create socket
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_IF, socket.inet_aton(self.localIp))
        self.sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
        membership_request = socket.inet_aton(self.address) + socket.inet_aton(self.localIp)

        # See http://www.tldp.org/HOWTO/Multicast-HOWTO-6.html for explanation of sockopts
        self.sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, membership_request)

        # Bind the socket to an interface depending on system
        if platform.system() == 'Darwin':
            self.sock.bind(('0.0.0.0', self.port))
        else:
            self.sock.bind((self.localIp, self.port))

    def leave(self):
        # leave group if active
        if (self.address != None):
            membership_request = socket.inet_aton(self.address) + socket.inet_aton(self.localIp)
            self.sock.setsockopt(socket.IPPROTO_IP, socket.IP_DROP_MEMBERSHIP, membership_request)
            self.sock.close()
            self.address = None
            self.interface = None
            self.port = None
            self.localIp = None